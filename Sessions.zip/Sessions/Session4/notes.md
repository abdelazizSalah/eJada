# Session notes (Views)
* what does record mean? 
  * da 3bara 3n row fe table fe el database
  * w da byb2a 3bara 3n shwyt ma3lomat 
  * w da lama bagy a3rdha b3rdha fe 7aga esmha view.
* each view is related to certain entity
# View creation
* go to the solution
* select an entity
* select views
  * // now we need to define some properties
    1. what are the columns that we need to show in the view
    2. we can add new columns
    3. these columns are related to the entity that we selected (7agat mwgoda gowa el table elly bndwr 3leh)
    4. each column has some properties
       1. Name
       2. Description
    5. we can change these properties from change properties button
    6. we can change the width of the column -> used in reports
    7. the web resources which is the java script code
    8. the function name used in it and so on.
 

# Types Views
* View howa 3obara 3n table, gowah shwyt 7agat related bb3d, bona2an 3la characteristics mo3yna
* mmkn msln ab2a 3aml view l kol el items elly 3ndy.
* aw mmkn a3ml view feh kol el 3omala el mn masr bs msln. 
* w b3mlo 34an a2dr ashof properties mo3yna lel entities. 
* w gowah baa b2dr eny a-search 3la records mo3yna brdo. 
* 34an a-create view w a5leh yshmal nas mo3yna, fa bn3ml fl properties bt3to fitlering conditions/criteria. 
* types of views:
  * System view
    * to be able to make it you must have a security role called system adminstrator/system customizer
    * they are created by default for system entities (sales, marketing, customer services, etc...).
    * it has some additional capabilites
      * Advanced find view
      * associated view
      * look-up view
      * Quick find view
        * used in search filtration
        * da 3bara 3n eny a3ml search 3la kol el records elly bt722ly value mo3yna. 
        * fa ana b3ml view, esmo quick find view, da byb2a feh zy search field keda, bktb feha el keyword elly bdwr 3leh w hwa byzhrly kol el hagat el related baa, aw el matched. 
      * 34an a2dr baa eny a7ot critera mo3yna y3ml search beha, baro7 a3dl da gowa baa.
      * fa bdkhol 3la ay entity
      * w aft7 views
      * w y2ma a3ml new, aw ashof already created quick find view
      * w ados 3la button esmo edit filter criteria
         
  * we can not delete them
    * Quick find view:
      * enta bt3ml search sare3 fl view, fanta btdwr 3la kol el records elly m722a el condition elly ana 7ato, fa mmkn akon bdwr 3la kol names elly btsawy ahmed
      * kol arkam el telefon elly homa 010
      * 34an ne3ml keda, bn3ml edit filter w bt7dd el filter in wl filter for. 
      * 3ndna 7agten mohmen
        * And group
          * lazm y722 kol el shrot
        * Or group 
          * ay shart mnhom
    * system adminstrator
    * system customized. 
  * Public view:
    * f
  * Personal view:
    * we should nkno
  
# Business rule
* de 7aga bn3mlha 34an ne2dr n7ot conditions 3la el inserted fields wenta bt3ml creation lehom.
* w btb2a marbota b kol  entity. 
