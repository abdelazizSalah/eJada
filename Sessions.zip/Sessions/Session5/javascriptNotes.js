function firstFunction() {
    console.log("This is the first function");
}
