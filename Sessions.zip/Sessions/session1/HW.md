* what is the difference between the campaign and quick campaign?
  * el quick campaign 3auz 1 task bs, lakn el campaign byb2a feh multiple tasks. 
* official defination: A Campaign is a set of automated tasks whereas a Quick Campaign is just one automated task. 