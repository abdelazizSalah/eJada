# CRM
## Web based application used to automate sales,marketing and serivies activities in an organization
**Targets**
- Sales
- Marketing
- Customer Services
### Goals
- help organization acquire and retain customers 
- reduce the time spent on administrative tasks
- serve customers efficiently
> called 360 degree view : **Cause have all customers's info** 

1. Web based application
2.  Dynamics (Advanced marketing)
    1.  How many likes this 
    2.  How many comments this
    3.  How many favorite this
---
**WE have two options**
1. on permise (Locally)
2. on the cloud
   
---
##### Each entity has a `primary key` and `primary field`
> Currency in on permis doesn't change
> ADEFS in between local current and server`  
##### View : Display record

---
Campaign = 7amla
### List types
- Dynamic  (auto-mate entering customers in a list at any time)
- Static ( once campaign created , cannot be moved to any other customer)

###### Example: Dynamic used in notification alerts , 


## Difference between Contact , Account and Lead (Targets)
- Account --> Organization
- Contact --> Individuals in Organization
- Contact: already registered in Company
- Lead : lsa hyegy meno w 7ases eno interesed w mmkn ageb reglo fe el Comapany
  
### Each entity has a 
- modified in , on and by 
- Currency
- Locked (depends on List type)
- Source
  

### Subgrid: Shows table from oth/er entities
**Lockups**

### Campaign
-  Status : Active or inActive
-  Approved or rejected
-  Code : Random Number (Auto numbering from script)
- Can have more than list of marketing
- Activites (tasks that we have discussed before)
- Leads (Customers that We have already invited and ended accepted)
- `Financial:` **Miscellaneous cost** ==> mkntsh 3amel 7easbha fe el cost, **Activity cost** (mn el campaign cost) , **Allocated** budget (expected budget) and **Total cost** (Actual cost)


> Microsoft can make an auditing to any companies which are not use whole features that provides these companies ,, `Ex: lw sherka buy an license w kaman md5la ms waset ,, w 3mlt 7aga already mawgoda f kda hya 3mlt  `


### Difference between Campaign and Quick Campaign
- **Quick Campian:** automated task as (email, phone..) 
- **Campian:** set of automated tasks
---

#### Sales Hub
**Cycle**:
1. Lead Opportunity
2. Qualification
3. Development 
4. Propose
5. Close


`b3d m 5lsna l lead w 3mlnalo qualify b2a ==> opportunity` 
`kol opportunity leha product`

 **Right-in product `msh` byt7t fl products table da byt-create fe sa3etha**

 ### Product
 ##### Sales Relationships
 1. up-sell (upgrade lel product bta3y)
 2. Cross-sell (habe3 7agten m3 b3d (**balsem w shampoo**))
 3. Accessory (habe3 7agten m3 b3d mn nfs l no3 zy l mob m3ah sha7n)
 4. Substitute
   


### Costs Types
1. Current Cost ( el se3r l 7aly , mfrod hwa byb2a  a3la mn standard cost)
2. Standard Cost (se3r el so2 l asly)

### What is a price list?
Price lists tell your sales agents what to charge for your products or services.