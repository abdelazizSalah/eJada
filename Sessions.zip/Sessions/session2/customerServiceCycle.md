# Customer Service Cycle
* el cycle btbd2 en fe wahed fl call center bygelo call
* lama bn3ml automate lel klam da m3 el call center, byndh 3la el api automatically fa yeft7lo el contact bta3 el shakhs el bytsl
* bs lw msh mwgod ka agent btft7 el contact bta3 el shakhs el bytsl
* el contact byb2a gowah shwyt general information about the customer
  * first name
  * last name
  * organization
  * mobile phone w hakaza.
  * contact method: // prefered contact method blnesba lel client
    * phone
    * mail
    * fax 
    * others.
  * addresses. 
  * Job title
  * business phone number. 
* Timeline: // da baa el mkan byzhr feh el activities elly bt7sl m3 el contact da
  * create a note: bnktb gowah notes 3n el shakhs da. 
  * el contact da byb2a esmo 365 contact, w da m3nah eny bshof kol tfaselo 34an a3rf a el shkawy el 3mlha abl keda w bytklm usually leh w hakaza. 

## Sections
 * byb2o tfasel 3n kol contact zy el Details wl Tab wl Summary w hakaza. 

## Details
* tfasel 3n el shakhs da baa, w el hadaf mn keda eno yest5dmhom fl marketing campaigns. 
*  Marketings section:
   *  Originating lead: da by2oly hwa asl el shakhs da gy mnen, lw hwa kan lead hayb2a zaher 3ndy keda.
   *  last campaign date: akher mara 7dr campaign. 
   *  Marketing Materials: Send/ don't send, neb3tlo wla laa. 

## Contact Prefrences
* el shakhs da byfdl tare2t el twasol m3ah tb2a 3amla ezay w hakaza.

## Billing
* m3ah ad a 
* el credit limit bta3o
* el payment terms bta3o
  * by7b yedf3 30 Net msln aw 50 Net aw keda

## Shipping
* Shipping Method: hanwslo ezay
* Freight Terms: lw 3auz awslhalo le mena msln, aw eno hwa ely haytsrf.



## open org chart button
* de page btwreny el chart bta3t el organization. 
* fa lw feh kaza contact mtwslen bb3d keda, htla2y zy graph keda w el nodes bt3to 3bara 3n contacts, w el edges btwsly el contacts bb3d. 

## Related 
*  Sales :
   *  Leads
   *  Opportunities
* Services: 
  * cases (service request / tickets): 
    * de el 7alat elly el customers by3mloha, zy shakawy aw keda.
    * fa 3auz te3ml case gdeda btdos new case, w tbd2 temla el details
      * Customer: Account / contact
      * case title: eh el moshkela
      * Subject: 
        * Auto-drip
        * Clogged drain
        * General (others).
      * Case type:  no3 el case, w de haga mmkn ab2a a3dlha.
        * Question
        * Problem
        * Request
      * Contact: 
      * Assign to others: 7d tany hwa elly el mfrod yshof el mwdo3 da.
      * Parent case: aknk btrbot el case de b case adema msln, aw two cases bytklmo 3n nfs el subject fa brbothom bb3d. 
      * Origin: el case de gatly mnen bzbt
        * web 
        * others...
      * Product: eh el product elly 3leh el shakwa de. 
      * Entitlement: da akno el contract ben el 3amel w el organization elly btwfr el khadamat de, fa lw el 3amel eshtra meny product mo3yn, fa bn2dmlo fatort daman, lw eshtka mrten ha3mlhomlo bblash, lakn el talta h7asbo 3leha, aw akon m3rf duration shahr msln, fe khlalo h3mlo ay haga bblash lakn b3d keda h7asbo. 
      * First Response by:
        *  lazm el agent yet3aml fe el duration da. lw 3mlha b3dha bn3ml (esculation -> hansa3ad el mwdo3 le 7d akbur). 
        * bn7ddo 3la 7sb no3 el case.
      * Resolved by: el moshkela et7lt emta.
      * timeline: de brdu feha el activities elly bt7sl. 
  
  ## cases and entitlement icon
      * Recent cases: de el cases elly el customer by3mlhom, 34an lw l2et 7agat motshabha, fa ba2flha, aw lw l2et entnen fe benhom relation fa b3ml parent-child relation. 

##  knowleadge base icon
* da bn7ot gowah articles 34an mmkn ts3dk enk te3ml solve lel problems elly el customers by3mlha, fa t7l el case bshkl asr3, fa enta btdwr 3lehom b est5dam keyword mo3yn msln. 
* w de faydetha en el agent lw msh 7afez el khtwat, byft7 el article da w yebd2 yeshr7lo el khtwat.
* w dol byb2a gowaha 7lol le shwyt common cases. 

## similar cases icon
* de b7ot feha cases shabah el case el ana b7lha delw2ty, w 34an ye7sl keda byb2a feh shwyt conditions b7othom 34an a2ol en two cases are similar, zy msln lw lehom nfs el title, aw btklm 3n steps sabta aw fe proporties common aw keda.

## Applicable SLA (Service limit agreement)
* SLA de btf2 m3 el 3mel el service de hta5ud ad a w no3 el shakwa de byt7l fe w2t ad a w keda. 
* el klam da byzhr akno counter fe el SLA tab.
* w da m3nah en el mfrod el mushkela tt7l abl ma el counter da ye5ls. 
* w byegy meno els SLA KPI Instance 
* w de haga tfkr feha aknk bt7dd levels w el mfrod kol level byakhud time ad a.
* Warning time: banbehak b email a2olk enk arbt t-fail
* Failure time: bnb3t mail lel manager n2olo el agent m2drsh y7l el moshkela fl time estimated. 
* succeeded on: da m3nah en el agent eder eno y7l el mushkela. 
* we will discuss them later.

## Social Details
* lw el dynamics mrbot b social media mo3yna
* fa bn5zn el profile bta3o w keda. 
* Received as: 
  * Lead
  * Contact
  * Account
* Influence Score: 
* Sentiment Value: mn de wl fo2ha, b3rf mn el chat el client kan meday2 wla laa w el chat kan mashy ezay, w kol da bl machine learning. 

## Case Relationships
* babd2 agm3 el tfasel bta3t cases fe case whda bs w bnsmeha (merged case)
* child cases: en 3ndk case child lel case bt3tk 
* associated knowledge record : de bn7ot feha el articles elly sa3detny fe eny a7l el case de, fa b5znha m3aha 34an ab2a 3aref anhy article el 7ltly da.


## Assign 
* de en el mushkela akbur mn eny a7lha 3la el telefon, fa bnb3t team lel mkan el feh el moshkela 34an ye7lha. 

## Do not decrement entitlement terms
* da m3nah eny masmo7ly a7l le shakhs mo3yn msln 10 cases msln, fa kol ma b7l case lazm a3ml decrement lel  counter da, lakn lw 3mlt cases motshabhen el mfrod m3mlsh decrement lel shakhs da.

## word templetes
* da 34an lw 3auz a3ml print le saf7a mo3yna fa b7otha fl templemt w atb3ha. 

## Save and route button
* lw el agent m2drsh ye7l el mushkela, fa bydos 3la save and route 34an ye7wlk 3la team tany ye2dr y7lelak el mushkela de. 
* lazm akon 3aml shwyt pre-defined steps keda hwa by3mlha bshkl automatic lama ados 3leh. 
* wl mfrod el case btro7 fe queue, 34an el team elly shaghal 3la el 7agat de by5tar case mn el queue w yeshtghl 3lehom. 
* el queue da bases 3la queue item
* el queue item de el case elly gowa el queue, w de el mfrod enha item mstnya tet7l. 
##  Resolve case
* bn2fel beha el case
* resolution type: enta afltha ezay
  * Information provided: enk bs admt shwyt m3lomat fa hwa mshy 3lehom w 7l el mushkela
  *  problem solved : eny sa3dto eno y7lha


## Reactive case
* de lw nfs el mushkela el kont afltha abl keda, el client klmny w aly en el mushkela zahrt tany, fa bdl ma aro7 aft7 case gdeda laa, b3ml reactive case w ashtghl 3leha tany. 
* w msh ay case b2dr a3mlha re-active, b7ot condition msln a2ol wlahy el client leh msln eno yeft7ha mrten bs lakn b3d keda lazm aft7lo case gdeda w a7sbo 3leha. 
* aw eny msln akhly msh ay 7d ye3ml re-active ll case, akhly el managers bs homa el y3mlo reactivation. 

## 