# Assignments 
* ndwr 3la eh el fields elly tb3 el process
  * Activity Count.
  * Activity Count including process. 
  * Execution Time -> el w2t el etnfzt feh el workflow. 
*  el steps lama b5tarha bttargm le anhy loght barmaga fl backend. 
*  wait condition (de el 7aga el mo5tlfa 3n el real time fe el background). 
   *  bnst5dmha ezay. 
*  