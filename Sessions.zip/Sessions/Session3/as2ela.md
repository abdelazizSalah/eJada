# Managed Properties
* mkontsh 3aref a3dl 3la aghlb el properties elly e5trthom, fa hya a el entities elly b2dr a3dl el managed properties bt3thom? 
> we can view only but not edit, to be able to edit we should follow the steps in this article : https://learn.microsoft.com/en-us/power-platform/alm/managed-properties-alm

> but the problem is that I do not find the three dots (...) which the article is talking about.  