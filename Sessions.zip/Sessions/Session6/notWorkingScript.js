// to debug, press f12 in chrome and go to console
// press ctrl + p
// search will appear, write the name of the file
// solve the errors. 